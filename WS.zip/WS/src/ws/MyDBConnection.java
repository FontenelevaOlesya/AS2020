package ws;
import java.sql.*;
import javax.swing.JOptionPane;
public class MyDBConnection {

    private Connection myConnection;
    
    public MyDBConnection() {

    }

     public void init(){
    
       try{        
        Class.forName("org.postgresql.Driver");
       myConnection=DriverManager.getConnection(
                "jdbc:postgresql://localhost:5434/WS","postgres", "0000"
                );
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Failed to get connection");
            e.printStackTrace();
        }
    }
    
    
    public Connection getMyConnection(){
        return myConnection;
    }
    
    
    public void close(ResultSet rs){
        
        if(rs !=null){
            try{
               rs.close();
            }
            catch(Exception e){}
        
        }
    }
    
     public void close(java.sql.Statement stmt){
        
        if(stmt !=null){
            try{
               stmt.close();
            }
            catch(Exception e){}
        
        }
    }
     
  public void destroy(){
  
    if(myConnection !=null){
    
         try{
               myConnection.close();
            }
            catch(Exception e){}
        
        
    }
  }
}
